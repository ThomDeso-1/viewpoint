import SwiftUI
import SwiftData

@main
struct ViewpointReceiptsApp: App {

    private let settings: AppSettings
    private let storageService: StorageService

    init() {
        let s = AppSettings()
        self.settings = s
        self.storageService = StorageService(settings: s)
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(settings)
                .environment(storageService)
        }
        .modelContainer(for: Receipt.self)
    }
}
