import SwiftUI
import SwiftData

@main
struct ViewpointReceiptsApp: App {

    private let settings: AppSettings
    private let storageService: StorageService
    private let uploadService: UploadService

    init() {
        let s = AppSettings()
        self.settings = s
        self.storageService = StorageService(settings: s)
        self.uploadService = UploadService(settings: s)
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(settings)
                .environment(storageService)
                .environment(uploadService)
        }
        .modelContainer(for: Receipt.self)
    }
}
